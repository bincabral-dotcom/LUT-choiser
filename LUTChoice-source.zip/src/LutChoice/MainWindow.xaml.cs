using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using LutChoice.Models;
using LutChoice.Services;
using Forms = System.Windows.Forms;
using Microsoft.Win32;

namespace LutChoice;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<LutPreview> _previews = [];
    private readonly FfmpegService _ffmpeg = new();
    private readonly string _workspace = Path.Combine(Path.GetTempPath(), "LUT-Choice", Guid.NewGuid().ToString("N"));
    private CancellationTokenSource? _generationCancellation;
    private string? _videoPath;
    private string? _lutFolder;
    private TimeSpan _videoDuration;
    private bool _videoReady;
    private bool _isGenerating;

    public MainWindow()
    {
        InitializeComponent();
        PreviewList.ItemsSource = _previews;
        Directory.CreateDirectory(_workspace);
    }

    private void OpenVideo_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Escolha um vídeo",
            Filter = "Vídeos|*.mp4;*.mov;*.mkv;*.avi;*.m4v;*.webm;*.wmv|Todos os arquivos|*.*"
        };
        if (dialog.ShowDialog() != true) return;

        _videoPath = dialog.FileName;
        _videoReady = false;
        FrameSlider.Value = 0;
        FrameSlider.IsEnabled = false;
        VideoNameText.Text = Path.GetFileName(_videoPath);
        StatusText.Text = "Lendo o vídeo…";
        VideoPreview.Stop();
        VideoPreview.Source = new Uri(_videoPath);
        UpdateActionAvailability();
    }

    private void ChooseFolder_Click(object sender, RoutedEventArgs e)
    {
        using var dialog = new Forms.FolderBrowserDialog
        {
            Description = "Escolha a pasta que contém os arquivos .cube",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = false
        };
        if (dialog.ShowDialog() != Forms.DialogResult.OK) return;

        _lutFolder = dialog.SelectedPath;
        var count = GetLutFiles().Count;
        LutFolderText.Text = _lutFolder;
        LutCountText.Text = count == 1
            ? "1 LUT .cube encontrado."
            : $"{count} LUTs .cube encontrados (inclui subpastas).";
        StatusText.Text = count == 0
            ? "Não encontrei arquivos .cube nessa pasta."
            : "Biblioteca carregada. Escolha um frame e gere as prévias.";
        UpdateActionAvailability();
    }

    private void VideoPreview_MediaOpened(object sender, RoutedEventArgs e)
    {
        if (!VideoPreview.NaturalDuration.HasTimeSpan)
        {
            StatusText.Text = "Não foi possível determinar a duração do vídeo.";
            return;
        }

        _videoDuration = VideoPreview.NaturalDuration.TimeSpan;
        _videoReady = _videoDuration > TimeSpan.Zero;
        FrameSlider.Maximum = Math.Max(_videoDuration.TotalSeconds, 0.001);
        FrameSlider.LargeChange = Math.Max(_videoDuration.TotalSeconds / 20, 1);
        FrameSlider.SmallChange = 0.04;
        FrameSlider.IsEnabled = _videoReady;
        TimeText.Text = FormatTime(TimeSpan.Zero);
        StatusText.Text = "Vídeo pronto. Escolha um instante na linha do tempo.";
        UpdateActionAvailability();
    }

    private void VideoPreview_MediaFailed(object sender, ExceptionRoutedEventArgs e)
    {
        _videoReady = false;
        FrameSlider.IsEnabled = false;
        StatusText.Text = "O Windows não conseguiu abrir este vídeo para visualização. Tente MP4/H.264 ou use outro arquivo.";
        UpdateActionAvailability();
    }

    private void FrameSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        var time = TimeSpan.FromSeconds(FrameSlider.Value);
        TimeText.Text = FormatTime(time);
        if (_videoReady)
            VideoPreview.Position = time;
    }

    private void Play_Click(object sender, RoutedEventArgs e)
    {
        if (_videoReady) VideoPreview.Play();
    }

    private void Pause_Click(object sender, RoutedEventArgs e)
    {
        VideoPreview.Pause();
    }

    private async void Generate_Click(object sender, RoutedEventArgs e)
    {
        if (_videoPath is null || _lutFolder is null || !_videoReady || _isGenerating) return;
        var luts = GetLutFiles();
        if (luts.Count == 0)
        {
            StatusText.Text = "Selecione uma pasta que contenha pelo menos um arquivo .cube.";
            return;
        }

        _isGenerating = true;
        _generationCancellation = new CancellationTokenSource();
        var token = _generationCancellation.Token;
        _previews.Clear();
        PreviewList.SelectedItem = null;
        SelectedLutText.Text = "Nenhuma LUT selecionada";
        ExportButton.IsEnabled = false;
        foreach (var lut in luts)
            _previews.Add(new LutPreview(lut));
        PreviewList.Visibility = Visibility.Visible;
        EmptyStateText.Visibility = Visibility.Collapsed;
        UpdateActionAvailability();

        var frameTime = TimeSpan.FromSeconds(FrameSlider.Value);
        var renderFolder = Path.Combine(_workspace, Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(renderFolder);
        var completed = 0;
        var errors = 0;
        using var limiter = new SemaphoreSlim(2);
        StatusText.Text = $"Gerando 0 de {luts.Count} prévias…";

        try
        {
            var tasks = _previews.Select(async (preview, index) =>
            {
                var slotAcquired = false;
                try
                {
                    await limiter.WaitAsync(token);
                    slotAcquired = true;
                    await Dispatcher.InvokeAsync(() => preview.StateLabel = "Gerando…");
                    var output = Path.Combine(renderFolder, $"{index:D4}.jpg");
                    await _ffmpeg.CreateLutPreviewAsync(_videoPath, frameTime, preview.Path, output, token);
                    var bitmap = LoadBitmap(output);
                    await Dispatcher.InvokeAsync(() =>
                    {
                        preview.Thumbnail = bitmap;
                        preview.StateLabel = "Pronta";
                    });
                }
                catch (OperationCanceledException)
                {
                    await Dispatcher.InvokeAsync(() => preview.StateLabel = "Cancelada");
                }
                catch (Exception ex)
                {
                    Interlocked.Increment(ref errors);
                    await Dispatcher.InvokeAsync(() =>
                    {
                        preview.StateLabel = "Não foi possível gerar";
                        preview.Detail = ex.Message;
                    });
                }
                finally
                {
                    if (slotAcquired) limiter.Release();
                    var done = Interlocked.Increment(ref completed);
                    await Dispatcher.InvokeAsync(() => StatusText.Text = $"Gerando {done} de {luts.Count} prévias…");
                }
            });

            await Task.WhenAll(tasks);
            StatusText.Text = token.IsCancellationRequested
                ? "Geração cancelada. As prévias concluídas continuam disponíveis."
                : errors == 0
                    ? $"{luts.Count} prévias prontas. Clique em uma para escolhê-la."
                    : $"Concluído: {luts.Count - errors} prévias prontas e {errors} com falha. Passe o mouse sobre uma falha para ver o motivo.";
        }
        finally
        {
            _generationCancellation?.Dispose();
            _generationCancellation = null;
            _isGenerating = false;
            UpdateActionAvailability();
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        _generationCancellation?.Cancel();
        CancelButton.IsEnabled = false;
        StatusText.Text = "Cancelando as prévias em andamento…";
    }

    private void Previews_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var selected = PreviewList.SelectedItem as LutPreview;
        if (selected?.IsReady != true)
        {
            ExportButton.IsEnabled = false;
            SelectedLutText.Text = "Escolha uma prévia gerada para exportar.";
            return;
        }

        SelectedLutText.Text = $"Selecionada: {selected.Name}";
        ExportButton.IsEnabled = !_isGenerating;
    }

    private async void Export_Click(object sender, RoutedEventArgs e)
    {
        if (_videoPath is null || PreviewList.SelectedItem is not LutPreview selected || !selected.IsReady) return;

        var safeName = string.Concat(selected.Name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        var dialog = new SaveFileDialog
        {
            Title = "Exportar frame com LUT",
            Filter = "Imagem JPEG|*.jpg",
            FileName = $"{Path.GetFileNameWithoutExtension(_videoPath)}_{safeName}.jpg"
        };
        if (dialog.ShowDialog() != true) return;

        ExportButton.IsEnabled = false;
        StatusText.Text = "Exportando frame em resolução original…";
        try
        {
            await _ffmpeg.ExportLutFrameAsync(
                _videoPath,
                TimeSpan.FromSeconds(FrameSlider.Value),
                selected.Path,
                dialog.FileName,
                CancellationToken.None);
            StatusText.Text = "Frame exportado com sucesso.";
            MessageBox.Show(this, "O frame tratado foi salvo.", "LUT Choice", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Não foi possível exportar o frame.";
            MessageBox.Show(this, ex.Message, "Falha ao exportar", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            ExportButton.IsEnabled = PreviewList.SelectedItem is LutPreview { IsReady: true } && !_isGenerating;
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        _generationCancellation?.Cancel();
        VideoPreview.Close();
        try { if (Directory.Exists(_workspace)) Directory.Delete(_workspace, recursive: true); } catch { /* temporary files may be locked */ }
        base.OnClosed(e);
    }

    private List<string> GetLutFiles()
    {
        if (string.IsNullOrWhiteSpace(_lutFolder) || !Directory.Exists(_lutFolder)) return [];
        try
        {
            return Directory.EnumerateFiles(_lutFolder, "*.cube", SearchOption.AllDirectories)
                .OrderBy(path => Path.GetFileName(path), StringComparer.CurrentCultureIgnoreCase)
                .ToList();
        }
        catch (UnauthorizedAccessException)
        {
            return [];
        }
    }

    private void UpdateActionAvailability()
    {
        var canGenerate = _videoReady && !string.IsNullOrWhiteSpace(_videoPath) && GetLutFiles().Count > 0 && !_isGenerating;
        GenerateButton.IsEnabled = canGenerate;
        CancelButton.IsEnabled = _isGenerating;
        OpenVideoButton.IsEnabled = !_isGenerating;
        ExportButton.IsEnabled = !_isGenerating && PreviewList.SelectedItem is LutPreview { IsReady: true };
    }

    private static BitmapImage LoadBitmap(string path)
    {
        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.UriSource = new Uri(path, UriKind.Absolute);
        image.EndInit();
        image.Freeze();
        return image;
    }

    private static string FormatTime(TimeSpan time) => $"{(int)time.TotalMinutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
}

