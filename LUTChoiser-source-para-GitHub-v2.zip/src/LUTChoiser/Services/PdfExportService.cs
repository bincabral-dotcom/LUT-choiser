using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Media.Imaging;
using LutChoiser.Models;

namespace LutChoiser.Services;

public static class PdfExportService
{
    private const double PageWidth = 841.89;
    private const double PageHeight = 595.28;
    private const double Margin = 32;
    private const double CardGap = 16;
    private const double CardHeight = 220;
    private const int ItemsPerPage = 4;

    public static Task ExportAsync(IReadOnlyList<LutPreview> previews, string outputPath, CancellationToken cancellationToken) =>
        Task.Run(() => CreatePdf(previews, outputPath, cancellationToken), cancellationToken);

    private static void CreatePdf(IReadOnlyList<LutPreview> previews, string outputPath, CancellationToken cancellationToken)
    {
        var images = previews.Select(preview => CreateImageItem(preview, cancellationToken)).ToList();
        if (images.Count == 0) throw new InvalidOperationException("Selecione ao menos uma miniatura pronta para gerar o PDF.");

        var pages = images.Chunk(ItemsPerPage).Select(chunk => chunk.ToList()).ToList();
        var nextObjectId = 4;
        var pageDefinitions = new List<PdfPage>();
        foreach (var pageImages in pages)
        {
            var page = new PdfPage(nextObjectId++, nextObjectId++, pageImages);
            foreach (var image in pageImages) image.ObjectId = nextObjectId++;
            pageDefinitions.Add(page);
        }

        var objects = new Dictionary<int, byte[]>();
        objects[1] = TextObject("<< /Type /Catalog /Pages 2 0 R >>");
        objects[2] = TextObject($"<< /Type /Pages /Kids [{string.Join(" ", pageDefinitions.Select(page => $"{page.PageObjectId} 0 R"))}] /Count {pageDefinitions.Count} >>");
        objects[3] = TextObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");

        for (var pageIndex = 0; pageIndex < pageDefinitions.Count; pageIndex++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var page = pageDefinitions[pageIndex];
            var resources = string.Join(" ", page.Images.Select((image, index) => $"/Im{index + 1} {image.ObjectId} 0 R"));
            objects[page.PageObjectId] = TextObject($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {Format(PageWidth)} {Format(PageHeight)}] /Resources << /Font << /F1 3 0 R >> /XObject << {resources} >> >> /Contents {page.ContentObjectId} 0 R >>");
            objects[page.ContentObjectId] = StreamObject("<<", CreatePageContent(page, pageIndex + 1, pageDefinitions.Count), compress: false);

            foreach (var image in page.Images)
            {
                var dictionary = $"<< /Type /XObject /Subtype /Image /Width {image.Width} /Height {image.Height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode";
                objects[image.ObjectId] = StreamObject(dictionary, image.Bytes, compress: false);
            }
        }

        var outputDirectory = Path.GetDirectoryName(outputPath);
        if (!string.IsNullOrWhiteSpace(outputDirectory)) Directory.CreateDirectory(outputDirectory);
        using var stream = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None);
        WriteAscii(stream, "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
        var offsets = new long[nextObjectId];
        for (var objectId = 1; objectId < nextObjectId; objectId++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            offsets[objectId] = stream.Position;
            WriteAscii(stream, $"{objectId} 0 obj\n");
            stream.Write(objects[objectId]);
            WriteAscii(stream, "\nendobj\n");
        }

        var xrefOffset = stream.Position;
        WriteAscii(stream, $"xref\n0 {nextObjectId}\n0000000000 65535 f \n");
        for (var objectId = 1; objectId < nextObjectId; objectId++)
            WriteAscii(stream, $"{offsets[objectId]:D10} 00000 n \n");
        WriteAscii(stream, $"trailer\n<< /Size {nextObjectId} /Root 1 0 R >>\nstartxref\n{xrefOffset}\n%%EOF");
    }

    private static PdfImage CreateImageItem(LutPreview preview, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (string.IsNullOrWhiteSpace(preview.ThumbnailPath) || !File.Exists(preview.ThumbnailPath))
            throw new FileNotFoundException("Uma das miniaturas selecionadas não está mais disponível.");

        using var file = File.OpenRead(preview.ThumbnailPath);
        var decoder = BitmapDecoder.Create(file, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
        var frame = decoder.Frames[0];
        return new PdfImage(preview.Name, File.ReadAllBytes(preview.ThumbnailPath), frame.PixelWidth, frame.PixelHeight);
    }

    private static byte[] CreatePageContent(PdfPage page, int pageNumber, int pageCount)
    {
        var content = new StringBuilder();
        content.Append("q\n0.975 0.969 0.988 rg\n0 0 ").Append(Format(PageWidth)).Append(' ').Append(Format(PageHeight)).Append(" re f\nQ\n");
        AddText(content, "LUT Choiser", Margin, PageHeight - 43, 19, "0.10 0.08 0.15");
        AddText(content, "LUTs selecionadas", Margin, PageHeight - 61, 10, "0.39 0.34 0.48");

        var cardWidth = (PageWidth - Margin * 2 - CardGap) / 2;
        for (var index = 0; index < page.Images.Count; index++)
        {
            var image = page.Images[index];
            var column = index % 2;
            var row = index / 2;
            var cardX = Margin + column * (cardWidth + CardGap);
            var cardY = PageHeight - 78 - (row + 1) * CardHeight - row * CardGap;
            content.Append("q\n0.93 0.91 0.96 rg\n")
                .Append(Format(cardX)).Append(' ').Append(Format(cardY)).Append(' ')
                .Append(Format(cardWidth)).Append(' ').Append(Format(CardHeight)).Append(" re f\nQ\n");

            var imageBoxX = cardX + 14;
            var imageBoxY = cardY + 61;
            var imageBoxWidth = cardWidth - 28;
            const double imageBoxHeight = 143;
            var ratio = Math.Min(imageBoxWidth / image.Width, imageBoxHeight / image.Height);
            var drawWidth = image.Width * ratio;
            var drawHeight = image.Height * ratio;
            var drawX = imageBoxX + (imageBoxWidth - drawWidth) / 2;
            var drawY = imageBoxY + (imageBoxHeight - drawHeight) / 2;
            content.Append("q\n").Append(Format(drawWidth)).Append(" 0 0 ").Append(Format(drawHeight)).Append(' ')
                .Append(Format(drawX)).Append(' ').Append(Format(drawY)).Append(" cm\n/Im").Append(index + 1).Append(" Do\nQ\n");

            var nameLines = WrapName(image.Name, 54).ToList();
            for (var line = 0; line < nameLines.Count; line++)
                AddText(content, nameLines[line], cardX + 14, cardY + 43 - line * 14, 11, "0.10 0.08 0.15");
        }

        AddText(content, $"Página {pageNumber} de {pageCount}", PageWidth - Margin - 70, 17, 9, "0.39 0.34 0.48");
        return Encoding.ASCII.GetBytes(content.ToString());
    }

    private static IEnumerable<string> WrapName(string value, int maximumCharacters)
    {
        var words = value.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (words.Length == 0) return ["LUT sem nome"];

        var lines = new List<string>();
        var line = new StringBuilder();
        foreach (var word in words)
        {
            if (line.Length > 0 && line.Length + word.Length + 1 > maximumCharacters)
            {
                lines.Add(line.ToString());
                line.Clear();
            }

            if (line.Length > 0) line.Append(' ');
            line.Append(word);
        }
        if (line.Length > 0) lines.Add(line.ToString());

        if (lines.Count <= 3) return lines;
        return [lines[0], lines[1], string.Join(' ', lines.Skip(2))];
    }

    private static void AddText(StringBuilder content, string value, double x, double y, double fontSize, string color)
    {
        content.Append("BT\n/F1 ").Append(Format(fontSize)).Append(" Tf\n")
            .Append(color).Append(" rg\n")
            .Append(Format(x)).Append(' ').Append(Format(y)).Append(" Td\n")
            .Append(ToPdfLiteral(value)).Append(" Tj\nET\n");
    }

    private static string ToPdfLiteral(string value)
    {
        var normalized = value.Normalize(NormalizationForm.FormC);
        var bytes = Encoding.Latin1.GetBytes(normalized);
        var result = new StringBuilder("(");
        foreach (var character in bytes)
        {
            switch (character)
            {
                case (byte)'(':
                case (byte)')':
                case (byte)'\\':
                    result.Append('\\').Append((char)character);
                    break;
                case < 32 or > 126:
                    result.Append('\\').Append(character.ToString("D3", CultureInfo.InvariantCulture));
                    break;
                default:
                    result.Append((char)character);
                    break;
            }
        }

        return result.Append(')').ToString();
    }

    private static byte[] TextObject(string value) => Encoding.ASCII.GetBytes(value);

    private static byte[] StreamObject(string dictionary, byte[] data, bool compress)
    {
        if (compress) throw new NotSupportedException("A exportação não usa compressão adicional.");
        var header = Encoding.ASCII.GetBytes($"{dictionary} /Length {data.Length} >>\nstream\n");
        var footer = Encoding.ASCII.GetBytes("\nendstream");
        var result = new byte[header.Length + data.Length + footer.Length];
        Buffer.BlockCopy(header, 0, result, 0, header.Length);
        Buffer.BlockCopy(data, 0, result, header.Length, data.Length);
        Buffer.BlockCopy(footer, 0, result, header.Length + data.Length, footer.Length);
        return result;
    }

    private static void WriteAscii(Stream stream, string text) => stream.Write(Encoding.ASCII.GetBytes(text));

    private static string Format(double value) => value.ToString("0.##", CultureInfo.InvariantCulture);

    private sealed class PdfPage(int pageObjectId, int contentObjectId, List<PdfImage> images)
    {
        public int PageObjectId { get; } = pageObjectId;
        public int ContentObjectId { get; } = contentObjectId;
        public List<PdfImage> Images { get; } = images;
    }

    private sealed class PdfImage(string name, byte[] bytes, int width, int height)
    {
        public string Name { get; } = name;
        public byte[] Bytes { get; } = bytes;
        public int Width { get; } = width;
        public int Height { get; } = height;
        public int ObjectId { get; set; }
    }
}
