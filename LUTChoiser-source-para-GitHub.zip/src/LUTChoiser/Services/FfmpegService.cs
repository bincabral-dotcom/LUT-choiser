using System.Diagnostics;
using System.Globalization;
using System.IO;

namespace LutChoiser.Services;

public sealed class FfmpegService
{
    public string ExecutablePath { get; }
    public string ProbeExecutablePath { get; }

    public FfmpegService()
    {
        var bundled = System.IO.Path.Combine(AppContext.BaseDirectory, "ffmpeg", "ffmpeg.exe");
        var bundledProbe = System.IO.Path.Combine(AppContext.BaseDirectory, "ffmpeg", "ffprobe.exe");
        ExecutablePath = File.Exists(bundled) ? bundled : "ffmpeg.exe";
        ProbeExecutablePath = File.Exists(bundledProbe) ? bundledProbe : "ffprobe.exe";
    }

    public async Task<TimeSpan> GetVideoDurationAsync(string videoPath, CancellationToken cancellationToken)
    {
        var output = await RunAsync(
            ProbeExecutablePath,
            ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", videoPath],
            cancellationToken);

        if (!double.TryParse(output.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var seconds) || seconds <= 0)
            throw new InvalidOperationException("Não foi possível identificar a duração do vídeo.");

        return TimeSpan.FromSeconds(seconds);
    }

    public Task CreateSourceFrameAsync(
        string videoPath,
        TimeSpan timestamp,
        string outputPath,
        CancellationToken cancellationToken) =>
        RunAsync(
            ExecutablePath,
            ["-y", "-hide_banner", "-loglevel", "error",
             "-ss", FormatTimestamp(timestamp), "-i", videoPath,
             "-frames:v", "1", "-vf", "scale=1000:-2", "-q:v", "2", outputPath],
            cancellationToken);

    public async Task CreateLutPreviewAsync(
        string videoPath,
        TimeSpan timestamp,
        string lutPath,
        string outputPath,
        CancellationToken cancellationToken)
    {
        var filterPath = EscapeForFilter(lutPath);
        var filter = $"lut3d=file='{filterPath}':interp=tetrahedral,scale=480:-2";

        await RunAsync(
            ExecutablePath,
            ["-y", "-hide_banner", "-loglevel", "error",
             "-ss", FormatTimestamp(timestamp), "-i", videoPath,
             "-frames:v", "1", "-vf", filter, "-q:v", "2", outputPath],
            cancellationToken);
    }

    public async Task ExportLutFrameAsync(
        string videoPath,
        TimeSpan timestamp,
        string lutPath,
        string outputPath,
        CancellationToken cancellationToken)
    {
        var filterPath = EscapeForFilter(lutPath);
        var filter = $"lut3d=file='{filterPath}':interp=tetrahedral";

        await RunAsync(
            ExecutablePath,
            ["-y", "-hide_banner", "-loglevel", "error",
             "-ss", FormatTimestamp(timestamp), "-i", videoPath,
             "-frames:v", "1", "-vf", filter, "-q:v", "2", outputPath],
            cancellationToken);
    }

    private static async Task<string> RunAsync(string executablePath, IReadOnlyList<string> arguments, CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = executablePath,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardError = true,
            RedirectStandardOutput = true
        };

        foreach (var argument in arguments)
            startInfo.ArgumentList.Add(argument);

        using var process = new Process { StartInfo = startInfo };
        try
        {
            process.Start();
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or FileNotFoundException)
        {
            throw new InvalidOperationException(
                "O FFmpeg ou FFprobe não foi encontrado. Use a versão baixada pelo GitHub Actions ou coloque os dois arquivos na pasta ffmpeg ao lado do aplicativo.", ex);
        }

        var errorTask = process.StandardError.ReadToEndAsync();
        var outputTask = process.StandardOutput.ReadToEndAsync();
        try
        {
            await process.WaitForExitAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            if (!process.HasExited)
                process.Kill(entireProcessTree: true);
            throw;
        }

        var standardError = await errorTask;
        var standardOutput = await outputTask;
        if (process.ExitCode != 0)
        {
            var message = string.IsNullOrWhiteSpace(standardError)
                ? "O FFmpeg não conseguiu gerar esta prévia."
                : standardError.Trim();
            throw new InvalidOperationException(message);
        }

        return standardOutput;
    }

    private static string EscapeForFilter(string value) => value
        .Replace("\\", "/")
        .Replace(":", "\\:")
        .Replace("'", "\\'");

    private static string FormatTimestamp(TimeSpan timestamp) =>
        timestamp.TotalSeconds.ToString("0.###", CultureInfo.InvariantCulture);
}

