using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using LutChoiser.Models;
using LutChoiser.Services;

namespace LutChoiser;

public partial class GalleryWindow : Window
{
    private readonly string _videoPath;
    private readonly string _lutFolder;
    private readonly TimeSpan _selectedTime;
    private readonly FfmpegService _ffmpeg = new();
    private readonly ObservableCollection<LutPreview> _previews = [];
    private readonly string _workspace = Path.Combine(Path.GetTempPath(), "LUT-Choiser", Guid.NewGuid().ToString("N"));
    private CancellationTokenSource? _generationCancellation;
    private bool _isGenerating;

    public GalleryWindow(string videoPath, string lutFolder, TimeSpan selectedTime)
    {
        _videoPath = videoPath;
        _lutFolder = lutFolder;
        _selectedTime = selectedTime;
        InitializeComponent();
        Directory.CreateDirectory(_workspace);
        PreviewList.ItemsSource = _previews;
        FrameInfoText.Text = $"Frame selecionado: {FormatTime(_selectedTime)}  •  {GetLutFiles().Count} LUTs encontrados";
    }

    private async void GalleryWindow_Loaded(object sender, RoutedEventArgs e) => await GeneratePreviewsAsync();

    private async void Regenerate_Click(object sender, RoutedEventArgs e) => await GeneratePreviewsAsync();

    private async Task GeneratePreviewsAsync()
    {
        if (_isGenerating) return;
        var luts = GetLutFiles();
        if (luts.Count == 0)
        {
            StatusText.Text = "A pasta selecionada não possui arquivos .cube.";
            return;
        }

        _isGenerating = true;
        _generationCancellation = new CancellationTokenSource();
        var token = _generationCancellation.Token;
        _previews.Clear();
        PreviewList.SelectedItems.Clear();
        SelectedLutText.Text = "Clique nas miniaturas de que você gostar. É possível selecionar mais de uma.";
        ExportButton.IsEnabled = false;
        PdfButton.IsEnabled = false;
        foreach (var lut in luts) _previews.Add(new LutPreview(lut));
        PreviewList.Visibility = Visibility.Visible;
        EmptyStateText.Visibility = Visibility.Collapsed;
        UpdateActionAvailability();

        var renderFolder = Path.Combine(_workspace, Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(renderFolder);
        var completed = 0;
        var errors = 0;
        using var limiter = new SemaphoreSlim(2);
        StatusText.Text = $"Gerando 0 de {luts.Count} prévias…";

        try
        {
            var tasks = _previews.Select(async (preview, index) =>
            {
                var slotAcquired = false;
                try
                {
                    await limiter.WaitAsync(token);
                    slotAcquired = true;
                    await Dispatcher.InvokeAsync(() => preview.StateLabel = "Gerando…");
                    var output = Path.Combine(renderFolder, $"{index:D4}.jpg");
                    await _ffmpeg.CreateLutPreviewAsync(_videoPath, _selectedTime, preview.Path, output, token);
                    var bitmap = LoadBitmap(output);
                    await Dispatcher.InvokeAsync(() =>
                    {
                        preview.Thumbnail = bitmap;
                        preview.ThumbnailPath = output;
                        preview.StateLabel = "Pronta";
                    });
                }
                catch (OperationCanceledException)
                {
                    await Dispatcher.InvokeAsync(() => preview.StateLabel = "Cancelada");
                }
                catch (Exception ex)
                {
                    Interlocked.Increment(ref errors);
                    await Dispatcher.InvokeAsync(() =>
                    {
                        preview.StateLabel = "Não foi possível gerar";
                        preview.Detail = ex.Message;
                    });
                }
                finally
                {
                    if (slotAcquired) limiter.Release();
                    var done = Interlocked.Increment(ref completed);
                    await Dispatcher.InvokeAsync(() => StatusText.Text = $"Gerando {done} de {luts.Count} prévias…");
                }
            });

            await Task.WhenAll(tasks);
            StatusText.Text = token.IsCancellationRequested
                ? "Geração cancelada. As prévias concluídas continuam disponíveis."
                : errors == 0
                    ? $"{luts.Count} prévias prontas. Clique em uma ou mais para selecioná-las."
                    : $"Concluído: {luts.Count - errors} prévias prontas e {errors} com falha.";
        }
        finally
        {
            _generationCancellation?.Dispose();
            _generationCancellation = null;
            _isGenerating = false;
            UpdateActionAvailability();
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        _generationCancellation?.Cancel();
        CancelButton.IsEnabled = false;
        StatusText.Text = "Cancelando as prévias em andamento…";
    }

    private void Back_Click(object sender, RoutedEventArgs e) => Close();

    private void Previews_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var selected = GetSelectedReadyPreviews();
        var selectedCount = PreviewList.SelectedItems.OfType<LutPreview>().Count();
        if (selectedCount == 0)
        {
            ExportButton.IsEnabled = false;
            PdfButton.IsEnabled = false;
            SelectedLutText.Text = "Clique nas miniaturas de que você gostar. É possível selecionar mais de uma.";
            return;
        }

        if (selected.Count != selectedCount)
        {
            SelectedLutText.Text = $"{selectedCount} selecionadas. Aguarde a geração das miniaturas restantes.";
            ExportButton.IsEnabled = false;
            PdfButton.IsEnabled = false;
            return;
        }

        SelectedLutText.Text = selected.Count == 1
            ? $"1 LUT selecionada: {selected[0].Name}"
            : $"{selected.Count} LUTs selecionadas para o PDF.";
        ExportButton.IsEnabled = !_isGenerating && selected.Count == 1;
        PdfButton.IsEnabled = !_isGenerating;
    }

    private async void Export_Click(object sender, RoutedEventArgs e)
    {
        var selections = GetSelectedReadyPreviews();
        if (selections.Count != 1) return;
        var selected = selections[0];
        var safeName = string.Concat(selected.Name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = "Exportar frame com LUT",
            Filter = "Imagem JPEG|*.jpg",
            FileName = $"{Path.GetFileNameWithoutExtension(_videoPath)}_{safeName}.jpg"
        };
        if (dialog.ShowDialog() != true) return;

        ExportButton.IsEnabled = false;
        StatusText.Text = "Exportando frame em resolução original…";
        try
        {
            await _ffmpeg.ExportLutFrameAsync(_videoPath, _selectedTime, selected.Path, dialog.FileName, CancellationToken.None);
            StatusText.Text = "Frame exportado com sucesso.";
            System.Windows.MessageBox.Show(this, "O frame tratado foi salvo.", "LUT Choiser", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Não foi possível exportar o frame.";
            System.Windows.MessageBox.Show(this, ex.Message, "Falha ao exportar", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            UpdateActionAvailability();
        }
    }

    private async void ExportPdf_Click(object sender, RoutedEventArgs e)
    {
        var selections = GetSelectedReadyPreviews();
        if (selections.Count == 0) return;

        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = "Salvar PDF das LUTs selecionadas",
            Filter = "Documento PDF|*.pdf",
            FileName = $"{Path.GetFileNameWithoutExtension(_videoPath)}_LUTs_selecionadas.pdf"
        };
        if (dialog.ShowDialog() != true) return;

        PdfButton.IsEnabled = false;
        ExportButton.IsEnabled = false;
        StatusText.Text = $"Montando PDF com {selections.Count} LUT{(selections.Count == 1 ? string.Empty : "s")} selecionada{(selections.Count == 1 ? string.Empty : "s")}…";
        try
        {
            await PdfExportService.ExportAsync(selections, dialog.FileName, CancellationToken.None);
            StatusText.Text = "PDF salvo com as miniaturas e os nomes das LUTs selecionadas.";
            System.Windows.MessageBox.Show(this, "O PDF foi salvo com sucesso.", "LUT Choiser", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Não foi possível gerar o PDF.";
            System.Windows.MessageBox.Show(this, ex.Message, "Falha ao gerar PDF", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            UpdateActionAvailability();
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        _generationCancellation?.Cancel();
        try { if (Directory.Exists(_workspace)) Directory.Delete(_workspace, recursive: true); } catch { /* temporary files can be locked */ }
        base.OnClosed(e);
    }

    private List<string> GetLutFiles()
    {
        try
        {
            return Directory.EnumerateFiles(_lutFolder, "*.cube", SearchOption.AllDirectories)
                .OrderBy(path => Path.GetFileName(path), StringComparer.CurrentCultureIgnoreCase)
                .ToList();
        }
        catch (UnauthorizedAccessException) { return []; }
    }

    private void UpdateActionAvailability()
    {
        RegenerateButton.IsEnabled = !_isGenerating;
        CancelButton.IsEnabled = _isGenerating;
        var selected = GetSelectedReadyPreviews();
        var allSelectedAreReady = selected.Count == PreviewList.SelectedItems.Count;
        ExportButton.IsEnabled = !_isGenerating && allSelectedAreReady && selected.Count == 1;
        PdfButton.IsEnabled = !_isGenerating && allSelectedAreReady && selected.Count > 0;
    }

    private List<LutPreview> GetSelectedReadyPreviews() => PreviewList.SelectedItems
        .OfType<LutPreview>()
        .Where(preview => preview.IsReady && !string.IsNullOrWhiteSpace(preview.ThumbnailPath))
        .ToList();

    private static BitmapImage LoadBitmap(string path)
    {
        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.UriSource = new Uri(path, UriKind.Absolute);
        image.EndInit();
        image.Freeze();
        return image;
    }

    private static string FormatTime(TimeSpan time) => $"{(int)time.TotalMinutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
}
