using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LutChoiser.Services;
using Forms = System.Windows.Forms;

namespace LutChoiser;

public partial class MainWindow : Window
{
    private readonly FfmpegService _ffmpeg = new();
    private readonly AppSettings _settings;
    private readonly string _workspace = Path.Combine(Path.GetTempPath(), "LUT-Choiser", Guid.NewGuid().ToString("N"));
    private CancellationTokenSource? _frameCancellation;
    private string? _videoPath;
    private string? _lutFolder;
    private TimeSpan _videoDuration;
    private bool _loadingVideo;
    private int _frameRequest;

    public MainWindow()
    {
        InitializeComponent();
        Directory.CreateDirectory(_workspace);
        _settings = AppSettingsService.Load();
        RestoreSavedLutFolder();
    }

    private async void OpenVideo_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Escolha um vídeo",
            Filter = "Vídeos|*.mp4;*.mov;*.mkv;*.avi;*.m4v;*.webm;*.wmv|Todos os arquivos|*.*",
            InitialDirectory = GetExistingDirectory(_settings.LastVideoFolder)
        };
        if (dialog.ShowDialog() != true) return;

        _videoPath = dialog.FileName;
        _settings.LastVideoFolder = Path.GetDirectoryName(_videoPath);
        AppSettingsService.Save(_settings);
        _videoDuration = TimeSpan.Zero;
        _loadingVideo = true;
        _frameCancellation?.Cancel();
        FrameSlider.Value = 0;
        FrameSlider.IsEnabled = false;
        VideoNameText.Text = Path.GetFileName(_videoPath);
        FrameImage.Source = null;
        FramePlaceholder.Visibility = Visibility.Visible;
        FrameLoadingOverlay.Visibility = Visibility.Visible;
        StatusText.Text = "Lendo a duração do vídeo…";
        UpdateActionAvailability();

        try
        {
            _videoDuration = await _ffmpeg.GetVideoDurationAsync(_videoPath, CancellationToken.None);
            FrameSlider.Maximum = Math.Max(_videoDuration.TotalSeconds, 0.001);
            FrameSlider.LargeChange = Math.Max(_videoDuration.TotalSeconds / 20, 1);
            FrameSlider.SmallChange = 0.04;
            FrameSlider.IsEnabled = true;
            TimeText.Text = FormatTime(TimeSpan.Zero);
            StatusText.Text = "Vídeo pronto. Clique na barra para escolher um frame.";
            await RefreshFrameAsync(debounce: false);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Não foi possível abrir este vídeo.";
            System.Windows.MessageBox.Show(this, ex.Message, "Falha ao abrir vídeo", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _loadingVideo = false;
            FrameLoadingOverlay.Visibility = Visibility.Collapsed;
            UpdateActionAvailability();
        }
    }

    private void ChooseFolder_Click(object sender, RoutedEventArgs e)
    {
        using var dialog = new Forms.FolderBrowserDialog
        {
            Description = "Escolha a pasta que contém os arquivos .cube",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = false,
            SelectedPath = GetExistingDirectory(_lutFolder ?? _settings.LastLutFolder)
        };
        if (dialog.ShowDialog() != Forms.DialogResult.OK) return;

        _lutFolder = dialog.SelectedPath;
        _settings.LastLutFolder = _lutFolder;
        AppSettingsService.Save(_settings);
        var count = UpdateLutFolderDetails();
        StatusText.Text = count == 0 ? "Não encontrei arquivos .cube nessa pasta." : "Biblioteca carregada. Escolha o frame e avance.";
        UpdateActionAvailability();
    }

    private void FrameSlider_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!FrameSlider.IsEnabled || FindVisualParent<Thumb>(e.OriginalSource as DependencyObject) is not null) return;

        FrameSlider.ApplyTemplate();
        var track = FrameSlider.Template.FindName("PART_Track", FrameSlider) as Track;
        if (track is null) return;

        var thumbWidth = track.Thumb?.ActualWidth ?? 0;
        var usableWidth = track.ActualWidth - thumbWidth;
        if (usableWidth <= 0) return;

        var position = e.GetPosition(track).X - thumbWidth / 2;
        var ratio = Math.Clamp(position / usableWidth, 0, 1);
        FrameSlider.Value = FrameSlider.Minimum + ratio * (FrameSlider.Maximum - FrameSlider.Minimum);
        e.Handled = true;
    }

    private async void FrameSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        TimeText.Text = FormatTime(TimeSpan.FromSeconds(FrameSlider.Value));
        if (_videoPath is not null && _videoDuration > TimeSpan.Zero && !_loadingVideo)
            await RefreshFrameAsync(debounce: true);
    }

    private async Task RefreshFrameAsync(bool debounce)
    {
        if (_videoPath is null) return;

        _frameCancellation?.Cancel();
        _frameCancellation?.Dispose();
        _frameCancellation = new CancellationTokenSource();
        var cancellationToken = _frameCancellation.Token;
        var request = ++_frameRequest;
        var timestamp = TimeSpan.FromSeconds(FrameSlider.Value);
        var outputPath = Path.Combine(_workspace, $"frame-{request:D5}.jpg");

        try
        {
            FrameLoadingOverlay.Visibility = Visibility.Visible;
            if (debounce) await Task.Delay(140, cancellationToken);
            await _ffmpeg.CreateSourceFrameAsync(_videoPath, timestamp, outputPath, cancellationToken);
            if (request != _frameRequest || cancellationToken.IsCancellationRequested) return;

            FrameImage.Source = LoadBitmap(outputPath);
            FramePlaceholder.Visibility = Visibility.Collapsed;
            StatusText.Text = "Frame atualizado. Quando estiver satisfeito, abra a comparação de LUTs.";
        }
        catch (OperationCanceledException)
        {
            // A pessoa continuou arrastando a barra; a solicitação mais nova substitui esta.
        }
        catch (Exception ex)
        {
            if (request == _frameRequest)
            {
                StatusText.Text = "Não foi possível gerar a prévia deste frame.";
                FramePlaceholder.Visibility = Visibility.Visible;
                System.Windows.MessageBox.Show(this, ex.Message, "Falha ao gerar frame", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        finally
        {
            if (request == _frameRequest)
                FrameLoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    private void OpenGallery_Click(object sender, RoutedEventArgs e)
    {
        if (_videoPath is null || _lutFolder is null || _videoDuration <= TimeSpan.Zero || GetLutFiles().Count == 0) return;

        var gallery = new GalleryWindow(_videoPath, _lutFolder, TimeSpan.FromSeconds(FrameSlider.Value)) { Owner = this };
        gallery.Closed += (_, _) =>
        {
            Show();
            Activate();
        };
        Hide();
        gallery.Show();
    }

    protected override void OnClosed(EventArgs e)
    {
        _frameCancellation?.Cancel();
        _frameCancellation?.Dispose();
        try { if (Directory.Exists(_workspace)) Directory.Delete(_workspace, recursive: true); } catch { /* temporary files can be locked */ }
        base.OnClosed(e);
    }

    private List<string> GetLutFiles()
    {
        if (string.IsNullOrWhiteSpace(_lutFolder) || !Directory.Exists(_lutFolder)) return [];
        try
        {
            return Directory.EnumerateFiles(_lutFolder, "*.cube", SearchOption.AllDirectories)
                .OrderBy(path => Path.GetFileName(path), StringComparer.CurrentCultureIgnoreCase)
                .ToList();
        }
        catch (UnauthorizedAccessException) { return []; }
    }

    private void UpdateActionAvailability() =>
        OpenGalleryButton.IsEnabled = !_loadingVideo && _videoDuration > TimeSpan.Zero && _videoPath is not null && GetLutFiles().Count > 0;

    private void RestoreSavedLutFolder()
    {
        var savedFolder = GetExistingDirectory(_settings.LastLutFolder);
        if (savedFolder is null) return;

        _lutFolder = savedFolder;
        var count = UpdateLutFolderDetails();
        StatusText.Text = count == 0
            ? "A biblioteca salva não possui arquivos .cube. Escolha outra pasta quando quiser."
            : "Biblioteca de LUTs restaurada. Importe um vídeo e escolha o frame.";
    }

    private int UpdateLutFolderDetails()
    {
        var count = GetLutFiles().Count;
        LutFolderText.Text = _lutFolder ?? "Nenhuma pasta selecionada";
        LutCountText.Text = count == 1 ? "1 LUT .cube encontrado." : $"{count} LUTs .cube encontrados (inclui subpastas).";
        return count;
    }

    private static string? GetExistingDirectory(string? path) =>
        !string.IsNullOrWhiteSpace(path) && Directory.Exists(path) ? path : null;

    private static T? FindVisualParent<T>(DependencyObject? element) where T : DependencyObject
    {
        while (element is not null)
        {
            if (element is T result) return result;
            element = VisualTreeHelper.GetParent(element);
        }

        return null;
    }

    private static BitmapImage LoadBitmap(string path)
    {
        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.UriSource = new Uri(path, UriKind.Absolute);
        image.EndInit();
        image.Freeze();
        return image;
    }

    private static string FormatTime(TimeSpan time) => $"{(int)time.TotalMinutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
}
