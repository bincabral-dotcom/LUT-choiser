using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;

namespace LutChoiser.Models;

public sealed class LutPreview : INotifyPropertyChanged
{
    private ImageSource? _thumbnail;
    private string? _thumbnailPath;
    private string _stateLabel = "Na fila";
    private string _detail = string.Empty;

    public LutPreview(string path)
    {
        Path = path;
        Name = System.IO.Path.GetFileNameWithoutExtension(path);
    }

    public string Name { get; }
    public string Path { get; }

    public ImageSource? Thumbnail
    {
        get => _thumbnail;
        set => SetField(ref _thumbnail, value);
    }

    public string? ThumbnailPath
    {
        get => _thumbnailPath;
        set => SetField(ref _thumbnailPath, value);
    }

    public string StateLabel
    {
        get => _stateLabel;
        set => SetField(ref _stateLabel, value);
    }

    public string Detail
    {
        get => _detail;
        set => SetField(ref _detail, value);
    }

    public bool IsReady => Thumbnail is not null;

    public event PropertyChangedEventHandler? PropertyChanged;

    private void SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        if (propertyName == nameof(Thumbnail))
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsReady)));
    }
}

