# LUT Choiser

Aplicativo Windows para comparar rapidamente LUTs (`.cube`) em um frame de vídeo.

## O que ele faz

1. Importe um vídeo.
2. Navegue até o instante desejado na linha do tempo.
3. Selecione a pasta que contém sua biblioteca de LUTs (`.cube`). A busca inclui subpastas.
4. Gere as prévias. Elas aparecem lado a lado, sempre em três colunas.
5. Clique na prévia preferida e, se desejar, exporte o frame final em JPEG.

Cada prévia é gerada pelo FFmpeg com interpolação tetraédrica, portanto corresponde à LUT real, não a uma simulação de cor feita pela interface.

## Rodar no computador

O aplicativo publicado pelo GitHub Actions já traz o FFmpeg e é portátil:

1. Baixe o artefato `LUT-Choice-win-x64` na aba **Actions** do GitHub.
2. Extraia o ZIP para uma pasta comum (não execute de dentro do arquivo compactado).
3. Abra `LUT Choiser.exe`.

O arquivo ZIP de distribuição é autocontido, mas o Windows precisa extrair o executável antes de iniciá-lo. Isso é uma limitação de segurança do próprio Windows.

## Compilar no GitHub

### Enviar o projeto compactado

1. Crie um repositório no GitHub e, uma única vez, crie o arquivo `.github/workflows/build-windows.yml` usando o conteúdo deste projeto.
2. Envie `LUTChoiser-source.zip` para a raiz desse repositório usando **Add file** → **Upload files**.
3. O envio do ZIP inicia a ação automaticamente. Ela o extrai somente no computador de compilação do GitHub.
4. Ao terminar, baixe o artefato `LUT-Choiser-win-x64`. Ele contém `LUT-Choiser-win-x64.zip`, pronto para distribuir.

> O GitHub Actions precisa conhecer o arquivo YAML antes de conseguir reagir ao envio do ZIP. Depois dessa configuração inicial, o código pode permanecer compactado no repositório; a ação faz a extração temporariamente e compila o aplicativo.

## Requisitos

- Windows 10/11, 64 bits.
- Nenhuma instalação adicional ao usar o pacote publicado pelo GitHub.
- LUTs no formato `.cube` compatível com o filtro `lut3d` do FFmpeg.

## Licenças de terceiros

O pacote gerado inclui `ffmpeg.exe`, instalado no runner de compilação pelo Chocolatey. O FFmpeg é distribuído sob GPL, cuja cópia e avisos acompanham o pacote quando disponíveis. Consulte [ffmpeg.org/legal.html](https://ffmpeg.org/legal.html) para detalhes. LUT Choiser apenas inicia o executável do FFmpeg para processar mídia.

