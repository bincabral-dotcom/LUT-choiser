using System.Diagnostics;
using System.Globalization;
using System.IO;

namespace LutChoiser.Services;

public sealed class FfmpegService
{
    public string ExecutablePath { get; }

    public FfmpegService()
    {
        var bundled = System.IO.Path.Combine(AppContext.BaseDirectory, "ffmpeg", "ffmpeg.exe");
        ExecutablePath = File.Exists(bundled) ? bundled : "ffmpeg.exe";
    }

    public async Task CreateLutPreviewAsync(
        string videoPath,
        TimeSpan timestamp,
        string lutPath,
        string outputPath,
        CancellationToken cancellationToken)
    {
        var filterPath = EscapeForFilter(lutPath);
        var filter = $"lut3d=file='{filterPath}':interp=tetrahedral,scale=480:-2";

        await RunAsync(
            ["-y", "-hide_banner", "-loglevel", "error",
             "-ss", FormatTimestamp(timestamp), "-i", videoPath,
             "-frames:v", "1", "-vf", filter, "-q:v", "2", outputPath],
            cancellationToken);
    }

    public async Task ExportLutFrameAsync(
        string videoPath,
        TimeSpan timestamp,
        string lutPath,
        string outputPath,
        CancellationToken cancellationToken)
    {
        var filterPath = EscapeForFilter(lutPath);
        var filter = $"lut3d=file='{filterPath}':interp=tetrahedral";

        await RunAsync(
            ["-y", "-hide_banner", "-loglevel", "error",
             "-ss", FormatTimestamp(timestamp), "-i", videoPath,
             "-frames:v", "1", "-vf", filter, "-q:v", "2", outputPath],
            cancellationToken);
    }

    private async Task RunAsync(IReadOnlyList<string> arguments, CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = ExecutablePath,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardError = true
        };

        foreach (var argument in arguments)
            startInfo.ArgumentList.Add(argument);

        using var process = new Process { StartInfo = startInfo };
        try
        {
            process.Start();
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or FileNotFoundException)
        {
            throw new InvalidOperationException(
                "O FFmpeg não foi encontrado. Use a versão baixada pelo GitHub Actions ou coloque ffmpeg.exe na pasta ffmpeg ao lado do aplicativo.", ex);
        }

        var errorTask = process.StandardError.ReadToEndAsync();
        try
        {
            await process.WaitForExitAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            if (!process.HasExited)
                process.Kill(entireProcessTree: true);
            throw;
        }

        var standardError = await errorTask;
        if (process.ExitCode != 0)
        {
            var message = string.IsNullOrWhiteSpace(standardError)
                ? "O FFmpeg não conseguiu gerar esta prévia."
                : standardError.Trim();
            throw new InvalidOperationException(message);
        }
    }

    private static string EscapeForFilter(string value) => value
        .Replace("\\", "/")
        .Replace(":", "\\:")
        .Replace("'", "\\'");

    private static string FormatTimestamp(TimeSpan timestamp) =>
        timestamp.TotalSeconds.ToString("0.###", CultureInfo.InvariantCulture);
}

